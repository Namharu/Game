/* Local development only. This file is excluded from GitHub. */
globalThis.LocalDonationTest = ({receive,clear,accepts}) => {
 let panel=document.getElementById('namePanel');const toggle=document.getElementById('panelToggle');if(!panel){panel=document.createElement('fieldset');panel.id='localTesting';document.querySelector('.preview').append(panel);}
 if(!panel||document.getElementById('localTestForm'))return;
 panel.hidden=false;if(toggle){toggle.hidden=true;toggle.textContent='로컬 테스트 · 네임택';toggle.setAttribute('aria-expanded','true');}
 const box=document.createElement('section');
 box.innerHTML='<h3>로컬 후원 테스트</h3><form id="localTestForm"><label>닉네임<input id="localTestName" value="남하루" required></label><label>단일 후원 개수<input id="localTestCount" type="number" min="1" max="1000000000" value="100" required></label><div class="actions"><button type="button" data-local-count="100">100개</button><button type="button" data-local-count="1000">1,000개</button></div><button type="submit">테스트 후원 띄우기</button><button type="button" id="localClearTests">테스트만 삭제</button></form><p id="localTestResult" role="status"></p><p>크기: 시그 오른쪽 아래 모서리 드래그 · Alt+휠 · 선택 후 +/−<br>T: 테스트 · X: 테스트 삭제 · H: 패널 열기/숨기기</p>';
 panel.prepend(box);
 const run=()=>{const name=box.querySelector('#localTestName').value.trim(),count=Number(box.querySelector('#localTestCount').value);if(!name||!Number.isSafeInteger(count)||count<1||count>1e9)return;const d={name,count,image:'',test:true,localTest:true};receive(d);box.querySelector('#localTestResult').textContent=accepts(d)?name+' · '+count.toLocaleString()+'개 표시':'현재 개수 조건에 맞지 않습니다.';};
 const remove=()=>{clear();box.querySelector('#localTestResult').textContent='로컬 테스트를 삭제했습니다.';};
 box.querySelector('form').onsubmit=e=>{e.preventDefault();run();};box.querySelector('#localClearTests').onclick=remove;
 box.querySelectorAll('[data-local-count]').forEach(b=>b.onclick=()=>{box.querySelector('#localTestCount').value=b.dataset.localCount;});
 addEventListener('keydown',e=>{if(e.repeat||e.ctrlKey||e.altKey||e.metaKey||e.shiftKey||e.target?.isContentEditable||['INPUT','TEXTAREA','SELECT'].includes(e.target?.tagName))return;if(e.code==='KeyT'){e.preventDefault();run();}else if(e.code==='KeyX'){e.preventDefault();remove();}});
};
